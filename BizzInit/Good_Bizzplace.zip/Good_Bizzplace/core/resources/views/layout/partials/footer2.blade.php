<!-- footer area one start -->
<footer class="footer-arae-two">
    <div class="copyright-area-two"><!-- copyright area -->
        <div class="container-fluid ">
            <div class="row">
                <div class="col-lg-12">
                    <div class="copyright-inner blue-bg"><!-- copyright inner -->
                        <div class="left-content-area">
                            <span class="copyright-text">Copyright © 2019 BizzPlace. Tous les droits sont réservés.</span>
                        </div>
                        <div class="right-content-area">
                            <ul class="payment-logo">
                                <li>
                                    <img src="assets/img/payment-logo/01.png" alt="payment logo">
                                </li>
                                <li>
                                    <img src="assets/img/payment-logo/02.png" alt="payment logo">
                                </li>
                                <li>
                                    <img src="assets/img/payment-logo/03.png" alt="payment logo">
                                </li>
                                <li>
                                    <img src="assets/img/payment-logo/04.png" alt="payment logo">
                                </li>
                                <li>
                                    <img src="assets/img/payment-logo/05.png" alt="payment logo">
                                </li>
                                <li>
                                    <img src="assets/img/payment-logo/06.png" alt="payment logo">
                                </li>
                                <li>
                                    <img src="assets/img/payment-logo/07.png" alt="payment logo">
                                </li>
                                <li>
                                    <img src="assets/img/payment-logo/08.png" alt="payment logo">
                                </li>
                            </ul>
                        </div>
                    </div><!-- //. copyright inner -->
                </div>
            </div>
        </div>
    </div><!-- //. copyright area -->
</footer>
<!-- footer area one end -->
