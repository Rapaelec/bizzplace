
    <!-- support bar area two start -->
    <div class="support-bar-two bg-white home-6">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="left-content">
                        <a href="<?php echo e(route('user.home')); ?>" class="logo main-logo">
                            <img src="<?php echo e(asset('assets/user/interfaceControl/logoIcon/logo.jpg')); ?>" alt="logo">
                        </a>
                    </div>
                    <div class="right-content">
                        <ul>
                            <li>
                                <div class="support-search-area">
                                    <form action="<?php echo e(url('/').'/shop'.'/'.Request::route('category').'/'.Request::route('subcategory')); ?>" class="search-form">
                                        <div class="form-element has-icon" action="<?php echo e(route('user.search')); ?>">
                                          <input name="term" type="text" class="input-field" placeholder="Recherche ..." value="<?php echo e(request()->input('term')); ?>">
                                          <div class="the-icon">
                                              <select class="category select selectpicker" onchange="categoryChange(this.value)">
                                                  <option value="" selected disabled>Categories</option>
                                                  <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                              </select>
                                          </div>
                                          <button type="submit" class="submit-btn"><i class="fas fa-search"></i></button>
                                        </div>
                                    </form>
                                </div>
                            </li>
                            <?php if(!Auth::check() && !Auth::guard('vendor')->check()): ?>
                            <li>
                                <div class="single-support-info-item">
                                    <div class="icon">
                                      <i class="fas fa-user-plus"></i>
                                    </div>
                                    <div class="content">
                                        <a href=" "><h4 class="title">S'inscrire</h4></a>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="single-support-info-item">
                                    <div class="icon">
                                            <i class="fas fa-users"></i>
                                    </div>
                                    <div class="content">
                                      <a href=""><h4 class="title">Se connecter</h4></a>
                                    </div>
                                </div>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- support bar area two end -->

    <!-- navbar area start -->
    <nav class="navbar navbar-area navbar-expand-lg navbar-light bg-light-blue home-6">
            <div class="container nav-container">
                <div class="logo-wrapper navbar-brand ">
                    <a href="index.html" class="logo main-logo mobile-logo">
                        <img src="<?php echo e(asset('assets/user/interfaceControl/logoIcon/logo.jpg')); ?>" alt="logo">
                    </a>
                    <?php if(!Auth::guard('vendor')->check()): ?>
                    <div class="form-element has-icon">
                        <select class="category selectpicker" onchange="categoryChange(this.value)">
                          <option value="" selected disabled>Categories</option>
                          <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>" <?php echo e(Request::route('category') == $category->id ? 'selected' : ''); ?>><?php echo e($category->name); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <span class="the-icon">
                                <i class="fas fa-plus"></i>
                        </span>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="collapse navbar-collapse" id="mirex">
                    <!-- navbar collapse start -->
                    <ul class="navbar-nav">
                        <!-- navbar- nav -->
                        <?php if(!Auth::guard('vendor')->check()): ?>
                          <li class="nav-item">
                              <a class="nav-link" href="<?php echo e(route('user.home')); ?>">Acceuil</a>
                          </li>
                          <li class="nav-item">
                              <a class="nav-link" href="">Cartes Cadeaux</a>
                          </li>
                        <?php endif; ?>
                        <?php if(auth()->guard('vendor')->check()): ?>
                          <li class="nav-item">
                              <a class="nav-link" href="<?php echo e(route('vendor.dashboard')); ?>">Dashboard</a>
                          </li>
                          <li class="nav-item">
                              <a class="nav-link" href="<?php echo e(route('package.index')); ?>">Packages</a>
                          </li>
                          <li class="nav-item">
                              <a class="nav-link" href="<?php echo e(route('vendor.showDepositMethods')); ?>">Dépôt</a>
                          </li>
                         <!--  <li class="nav-item">
                              <a class="nav-link" href="<?php echo e(route('vendor.withdrawMoney')); ?>">Withdraw</a>
                          </li> -->
                          <li class="nav-item">
                              <a class="nav-link" href="<?php echo e(route('vendor.orders')); ?>">Commande</a>
                          </li>
                          
                          <li class="nav-item dropdown">
                            <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">Message<sup><span class="badge badge-danger"><?php if(isset(Auth()->user()->notifications)): ?>
                            <?php echo e(Auth()->user()->unreadnotifications->count()==0 ? Auth()->user()->unreadnotifications->count() : Auth()->user()->unreadnotifications->count() .' new message'); ?><?php endif; ?></sup></span></a>
                            <div class="dropdown-menu">
                              <a href="<?php echo e(route('vendor.message.read')); ?>" class="dropdown-item">Marqué comme lu</a>
                            </div>
                          </li>
                          <li class="nav-item dropdown">
                              <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown">Produit</a>
                              <div class="dropdown-menu">
                                  <a href="<?php echo e(route('vendor.product.manage')); ?>" class="dropdown-item">Gestion Produit</a>
                                  <a href="<?php echo e(route('vendor.product.create')); ?>" class="dropdown-item">Charger le produit</a>
                              </div>
                          </li>
                          <li class="nav-item dropdown">
                              <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown">Livreurs</a>
                              <div class="dropdown-menu">
                                  <a href="<?php echo e(route('vendor.deliveryman.manage')); ?>" class="dropdown-item">Gestion Livreur</a>
                              </div>
                          </li>
                          <li class="nav-item dropdown">
                              <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown"><?php echo e(Auth::guard('vendor')->user()->shop_name); ?></a>
                              <div class="dropdown-menu">
                                  <a href="<?php echo e(route('vendor.setting')); ?>" class="dropdown-item">Reglage</a>
                                  <a href="<?php echo e(route('vendor.changePassword')); ?>" class="dropdown-item">Changer le mot de passe</a>
                                  <a href="<?php echo e(route('vendor.transactions')); ?>" class="dropdown-item">Historique Transaction </a>
                                  <a href="<?php echo e(route('vendor.couponlog')); ?>" class="dropdown-item">Historique Coupon </a>
                                  <a href="<?php echo e(route('vendor.logout', 1)); ?>" class="dropdown-item">Se déconnecter</a>
                              </div>
                          </li>
                        <?php endif; ?>
                        <?php if(!Auth::guard('vendor')->check()): ?>
                        <li class="nav-item dropdown mega-menu"><!-- mega menu start -->
                            <a class="nav-link dropdown-toggle" href="<?php echo e(route('user.search')); ?>" data-toggle="dropdown">Nos produits</a>
                            <div class="mega-menu-wrapper">
                                <div class="container mega-menu-container">
                                    <div class="row">
                                      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <div class="col-lg-2 col-sm-12">
                                            <div class="mega-menu-columns">
                                                <h6 class="title"><?php echo e($cat->name); ?></h6>
                                                <ul class="menga-menu-page-links">
                                                  <?php $__currentLoopData = $cat->subcategories()->where('status', 1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $subcat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><a href="<?php echo e(route('user.search', [$cat->id, $subcat->id])); ?>"><?php echo e($subcat->name); ?></a></li>
                                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            </div>
                                          </div>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                  </div>
                            </div>
                        </li>
                        <!-- mega menu end -->
                      

                        <li class="nav-item">
                            <a class="nav-link" href="">Annuaire</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="">Bons plans Partenaires</a>
                        </li>
                        
                        <?php if(!Auth::check() && !Auth::guard('vendor')->check()): ?>
                          
                          <li class="nav-item">
                              <a class="nav-link" href="<?php echo e(route('page_inscription')); ?>">Inscription Vendeur</a>
                          </li>
                        <?php elseif(Auth::check()): ?>  
                          <li class="nav-item dropdown">
                              <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown"><?php echo e(Auth::user()->username); ?></a>
                              <div class="dropdown-menu">
                                    <a class="dropdown-item" href="<?php echo e(route('user.profile')); ?>">Profile</a>
                                    <a class="dropdown-item" href="">Favoris</a>
                                    <a class="dropdown-item" href="<?php echo e(route('user.orders')); ?>">Commande</a>
                                    <a class="dropdown-item" href="<?php echo e(route('user.shipping')); ?>">Adresse de livraison</a>
                                    <a class="dropdown-item" href="<?php echo e(route('user.billing')); ?>">Adresse de facturation</a>
                                    <a class="dropdown-item" href="<?php echo e(route('user.logout')); ?>">Se déconnecter</a>
                              </div>
                          </li> 
                        <?php endif; ?>
                        <?php endif; ?>
                    </ul>
                    <!-- /.navbar-nav -->
                </div>
                <!-- /.navbar btn wrapper -->
                <div class="responsive-mobile-menu">
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#mirex" aria-controls="mirex"
                        aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                </div>
                <!-- navbar collapse end -->

                <?php if(!Auth::guard('vendor')->check()): ?>
                <div class="right-btn-wrapper">
                   <ul>
                       <?php if(!Auth::guard('vendor')->check() || request()->is('product/*/details') || request()->is('cart')): ?>
                       <li class="cart" id="cart"><i class="fas fa-shopping-bag"></i>
                        <span class="badge d-block" id="itemsCountVue">{{itemsCount}}</span>
                        <span class="badge d-none" id="itemsCountJquery"></span>
                       </li>
                       <?php endif; ?>
                   </ul>
                </div>
                <?php endif; ?>


            </div>
        </nav>
        <!-- navbar area end -->

        <div class="body-overlay" id="body-overlay"></div>
    <div class="search-popup" id="search-popup">
        <form action="index.html" class="search-popup-form">
            <div class="form-element">
                    <input type="text"  class="input-field" placeholder="Search.....">
            </div>
            <button type="submit" class="submit-btn"><i class="fas fa-search"></i></button>
        </form>
    </div>
    <!-- slide sidebar area start -->
    <div class="slide-sidebar-area" id="slide-sidebar-area">
        <div class="top-content"><!-- top content -->
            <a href="<?php echo e(route('user.home')); ?>" class="logo">
                <img src="<?php echo e(asset('assets/user/interfaceControl/logoIcon/logo.jpg')); ?>" alt="logo">
            </a>
            <span class="side-sidebar-close-btn" id="side-sidebar-close-btn"><i class="fas fa-times"></i></span>
        </div><!-- //. top content -->
    </div>
    <!-- slide sidebar area end -->

    <?php if(!Auth::guard('vendor')->check() || request()->is('product/*/details') || request()->is('cart')): ?>
      <!-- cart sidebar area start -->
      <div class="cart-sidebar-area" id="cart-sidebar-area">
          <div class="top-content"><!-- top content -->
              <a href="<?php echo e(route('user.home')); ?>" class="logo">
                  <img src="<?php echo e(asset('assets/user/interfaceControl/logoIcon/footer_logo.jpg')); ?>" alt="footer-logo">
              </a>
              <span class="side-sidebar-close-btn" ><i class="fas fa-times"></i></span>
          </div><!-- //. top content -->
          <div class="bottom-content"><!-- bottom content -->
              <div class="cart-products"><!-- cart product -->
                  <h4 class="title">Panier d'achat</h4>
                  <div class="">
                    <?php
                      if (Auth::check()) {
                        $sessionid = Auth::user()->id;
                      } else {
                        $sessionid = session()->get('browserid');
                      }
                      $carts = \App\Cart::where('cart_id', $sessionid)->get();
                    ?>

                    <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="single-product-item" id="singleitem<?php echo e($cart->id); ?>"><!-- single product item -->
                          <div class="thumb">
                              <img src="<?php echo e(asset('assets/user/img/products/') . '/' . \App\Product::find($cart->product_id)->previewimages()->first()->image); ?>" alt="recent review">
                          </div>
                          <div class="content">
                              <a href="<?php echo e(route('user.product.details', [$cart->product->slug, $cart->product->id])); ?>"><h4 class="title"><?php echo e(strlen($cart->title) > 18 ? substr($cart->title, 0, 18) . '...' : $cart->title); ?></h4></a>
                              <div class="price" style="font-size:12px;">
                                <?php if(empty($cart->current_price)): ?>
                                  <span class="pprice" id="price<?php echo e($cart->id); ?>"><?php echo e($gs->base_curr_symbol); ?> <?php echo e($cart->price); ?></span> <span class="sidequantity" id="quantity<?php echo e($cart->id); ?>">(<?php echo e($cart->quantity); ?>)</span>
                                <?php else: ?>
                                  <span class="pprice" id="price<?php echo e($cart->id); ?>"><?php echo e($gs->base_curr_symbol); ?> <?php echo e($cart->current_price); ?></span> <del id="delprice<?php echo e($cart->id); ?>" class="dprice"><?php echo e($gs->base_curr_symbol); ?> <?php echo e($cart->price); ?></del> <span class="sidequantity" id="quantity<?php echo e($cart->id); ?>">(<?php echo e($cart->quantity); ?>)</span>
                                <?php endif; ?>
                              </div>
                              <?php
                                $storedattr = json_decode($cart->attributes, true);
                              ?>
                              <?php if(count($storedattr) > 0): ?>
                                <div style="font-size:12px;">
                                  <?php
                                    $attrs = '';
                                    $j=0;
                                    foreach ($storedattr as $key => $values) {
                                      $attrs .= "".str_replace('_', ' ', $key).": ";
                                      $i = 0;
                                      foreach ($values as $v) {
                                        $attrs .= "$v";
                                        if (count($values)-1 != $i) {
                                          $attrs .= ", ";
                                        } else {
                                          $attrs .= " ";
                                        }
                                        $i++;
                                      }
                                      if (count($storedattr) - 1 != $j) {
                                        $attrs .= ' | ';
                                      }
                                      $j++;
                                    }
                                  ?>
                                  <?php echo e($attrs); ?>

                                </div>
                              <?php endif; ?>
                              <a style="font-size:12px;" href="#" class="remove-cart" @click="precartlen--;removeproduct(<?php echo e($cart->id); ?>)">Retiré</a>
                          </div>
                      </div><!-- //. single product item -->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="single-product-item" v-for="(product, index) in products"><!-- single product item -->
                        <div class="thumb">
                            <img :src="'<?php echo e(url('/assets/user/img/products/')); ?>'+'/'+product.preimg" alt="recent review">
                        </div>
                        <div class="content">
                            <a :href="'<?php echo e(url('/')); ?>/product/' + product.slug + '/' + product.id"><h4 class="title">{{product.title.length > 18 ? product.title.substring(0, 18) + '...' : product.title.substring}}</h4></a>
                            <div style="font-size:12px;" class="price" v-if="!product.current_price"><span class="pprice" :id="'price'+product.cart_id"><?php echo e($gs->base_curr_symbol); ?> {{product.price * product.quantity}}</span> <span :id="'quantity'+product.cart_id">({{product.quantity}})</span></div>
                            <div style="font-size:12px;" class="price" v-if="product.current_price"><span class="pprice" :id="'price'+product.cart_id"><?php echo e($gs->base_curr_symbol); ?> {{product.current_price * product.quantity}}</span> <del class="dprice" :id="'delprice'+product.cart_id"><?php echo e($gs->base_curr_symbol); ?> {{product.price * product.quantity}}</del> <span :id="'quantity'+product.cart_id">({{product.quantity}})</span></div>
                            <div style="font-size:12px;" v-if="product.countattr > 0">
                              {{product.attrs}}
                            </div>
                            <a style="font-size:12px;" href="#" class="remove-cart" @click="products.splice(index, 1);removeproduct(product.cart_id)">Retiré</a>
                        </div>
                    </div><!-- //. single product item -->

                    <div class="btn-wrapper" v-show="checkoutbtn" id="checkoutbtn">
                      <a href="" class="boxed-btn view-cart-btn">Panier</a>
                      <a href="" class="boxed-btn checkout-btn">Caisse</a>
                    </div>
                  </div>

                  <div v-show="noproduct">
                    <h4 class="text-center white-txt">AUCUN ELEMENT AJOUTE AU PANIER</h4>
                  </div>
                  <div id="noproduct" style="display:none;">
                    <h4 class="text-center white-txt">AUCUN ELEMENT AJOUTE AU PANIER</h4>
                  </div>
              </div> <!-- //. cart product -->
          </div><!-- //. bottom content -->
      </div>
      <!-- cart sidebar area end -->
    <?php endif; ?>
